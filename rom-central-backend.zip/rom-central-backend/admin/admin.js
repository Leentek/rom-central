// API Configuration
const API_BASE_URL = 'http://localhost:3000';
let authToken = null;

// DOM Elements
const loginContainer = document.getElementById('login-container');
const adminPanel = document.getElementById('admin-panel');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('logout-btn');
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const addGameBtn = document.getElementById('add-game-btn');
const gamesList = document.getElementById('games-list');
const gameModal = document.getElementById('game-modal');
const closeModalBtn = document.querySelector('.close-btn'); // Use querySelector for class
const gameForm = document.getElementById('game-form');
const modalTitle = document.getElementById('modal-title');
const gameIdInput = document.getElementById('game-id');
const titleInput = document.getElementById('title');
const platformInput = document.getElementById('platform');
const genreInput = document.getElementById('genre');
const descriptionInput = document.getElementById('description');
const coverInput = document.getElementById('cover');
const downloadInput = document.getElementById('download');
const saveGameBtn = document.getElementById('save-game-btn');

// Pagination elements
const paginationContainer = document.getElementById('pagination-container');
const prevPageBtn = document.getElementById('prev-page-btn');
const nextPageBtn = document.getElementById('next-page-btn');
const pageInfo = document.getElementById('page-info');
const platformFilter = document.getElementById('platform-filter');

// Blog Tab elements
const gamesTabContent = document.getElementById('games-tab'); // Reference to the games tab content
const blogTabContent = document.getElementById('blog-tab'); // Reference to the blog tab content
const tabBtns = document.querySelectorAll('.tab-btn');
const postsList = document.getElementById('posts-list');
const addPostBtn = document.getElementById('add-post-btn');
const postModal = document.getElementById('post-modal');
const closePostBtn = document.querySelector('.close-post-btn'); // Use querySelector for class
const postForm = document.getElementById('post-form');
const postModalTitle = document.getElementById('post-modal-title');
const postIdInput = document.getElementById('post-id');
const postTitleInput = document.getElementById('post-title');
const postAuthorInput = document.getElementById('post-author');
const postContentInput = document.getElementById('post-content');
const postImageInput = document.getElementById('post-image');
const postVideoInput = document.getElementById('post-video');
const savePostBtn = document.getElementById('save-post-btn');
const blogSearchInput = document.getElementById('blog-search-input');
const blogSearchBtn = document.getElementById('blog-search-btn');
const blogPrevPageBtn = document.getElementById('blog-prev-page-btn');
const blogNextPageBtn = document.getElementById('blog-next-page-btn');
const blogPageInfo = document.getElementById('blog-page-info');

// Games pagination state
let currentPage = 1;
const gamesPerPage = 10;
let totalGames = 0;
let totalPages = 1;

// Blog pagination state
let currentBlogPage = 1;
const postsPerPage = 5;
let totalPosts = 0;
let totalBlogPages = 1;


// Initialize the app
function init() {
    checkAuth();
    setupEventListeners(); // Call the single, merged function
    switchTab('games'); // Set games tab as active by default
}

// Check authentication status
function checkAuth() {
    const token = localStorage.getItem('adminToken');
    if (token) {
        authToken = token;
        loginContainer.classList.add('hidden');
        adminPanel.classList.remove('hidden');
        loadGames(); // Load games if logged in
    } else {
        loginContainer.classList.remove('hidden');
        adminPanel.classList.add('hidden');
    }
}

// API Request Helper
async function makeRequest(url, method = 'GET', body = null) {
    const headers = {
        'Content-Type': 'application/json'
    };

    if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
    }

    const options = {
        method,
        headers
    };

    if (body) {
        options.body = JSON.stringify(body);
    }

    try {
        const response = await fetch(`${API_BASE_URL}${url}`, options);

        if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                 // Unauthorized or Forbidden - likely bad token
                 logout(); // Log out the user
                 showError('Session expired or invalid. Please login again.');
                 return; // Stop further execution
            }
            const error = await response.json();
            throw new Error(error.error || error.message || 'Request failed');
        }
         // Handle cases where the response might be empty (e.g., DELETE requests)
         if (response.status === 204) { // No Content
            return null;
         }

        return await response.json();
    } catch (error) {
        console.error('API request failed:', error);
        // Avoid logging out for general network errors, only for auth issues
        if (!(error.message.includes('Session expired') || error.message.includes('Unauthorized'))) {
             showError('API request failed: ' + error.message);
        }
        throw error; // Re-throw error for calling function to handle if needed
    }
}


// --- Games Tab Functions ---

// Load games from server with pagination and filtering
async function loadGames() {
    if (!authToken) return; // Don't load if not logged in
    try {
        const platform = platformFilter.value;
        let url = `/games?page=${currentPage}&limit=${gamesPerPage}`;
        if (platform) {
            url += `&platform=${platform}`;
        }
        // Add search query if present
        const query = searchInput.value.trim();
        if (query) {
             url += `&q=${encodeURIComponent(query)}`;
        }

        const response = await makeRequest(url);
        if (!response) return; // Handle cases where makeRequest returns null (e.g., after logout)

        totalGames = response.totalGames;
        totalPages = response.totalPages;

        displayGames(response.games);
        updatePaginationUI();
    } catch (error) {
        // Error is already shown by makeRequest or subsequent calls
        // showError('Failed to load games: ' + error.message);
    }
}

// Update games pagination UI
function updatePaginationUI() {
    pageInfo.textContent = `Page ${currentPage} of ${totalPages} (${totalGames} games)`;
    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = currentPage === totalPages || totalPages === 0;
}

// Go to previous games page
function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        loadGames();
    }
}

// Go to next games page
function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        loadGames();
    }
}

// Display games in the UI
function displayGames(games) {
    gamesList.innerHTML = '';

    if (!games || games.length === 0) {
        gamesList.innerHTML = '<p class="no-games">No games found.</p>';
        return;
    }

    games.forEach(game => {
        const gameCard = document.createElement('div');
        gameCard.className = 'game-card';

        // Ensure genre is an array and join safely
        const genreText = Array.isArray(game.genre) ? game.genre.join(', ') : (game.genre || 'N/A');

        gameCard.innerHTML = `
            <img src="${game.cover || 'https://via.placeholder.com/300x200?text=No+Image'}" alt="${game.title}" class="game-cover" onerror="this.src='https://via.placeholder.com/300x200?text=Image+Error'">
            <div class="game-info">
                <h3 class="game-title">${game.title || 'Untitled'}</h3>
                <div class="game-meta">
                    <span>${game.platform || 'N/A'}</span>
                    <span>${genreText}</span>
                </div>
                <p class="game-description">${game.description || 'No description available.'}</p>
                <div class="game-actions">
                    <button class="edit-btn" data-id="${game.id}">Edit</button>
                    <button class="delete-btn" data-id="${game.id}">Delete</button>
                </div>
            </div>
        `;

        gamesList.appendChild(gameCard);
    });

    // Re-attach event listeners to new buttons
    document.querySelectorAll('#games-tab .edit-btn').forEach(btn => {
        btn.removeEventListener('click', handleEditGameClick); // Remove old listener if any
        btn.addEventListener('click', handleEditGameClick);
    });

    document.querySelectorAll('#games-tab .delete-btn').forEach(btn => {
        btn.removeEventListener('click', handleDeleteGameClick); // Remove old listener if any
        btn.addEventListener('click', handleDeleteGameClick);
    });
}

// Event handlers for game buttons to avoid closure issues in loops
function handleEditGameClick(event) {
    editGame(event.target.dataset.id);
}

function handleDeleteGameClick(event) {
    deleteGame(event.target.dataset.id);
}


// Search games
async function searchGames() {
    currentPage = 1; // Reset to first page when searching
    loadGames(); // loadGames now includes search query
}

// Add new game (opens modal)
function addNewGame() {
    modalTitle.textContent = 'Add New Game';
    gameForm.reset();
    gameIdInput.value = ''; // Ensure ID is cleared
    gameModal.classList.remove('hidden');
}

// Edit game (fetches data and opens modal)
async function editGame(id) {
    try {
        const game = await makeRequest(`/games/${id}`);
        if (!game) {
           showError('Game not found or failed to load.');
           return;
        }

        modalTitle.textContent = 'Edit Game';
        gameIdInput.value = game.id;
        titleInput.value = game.title || '';
        platformInput.value = game.platform || '';
        genreInput.value = Array.isArray(game.genre) ? game.genre.join(', ') : ''; // Handle potential non-array genre
        descriptionInput.value = game.description || '';
        coverInput.value = game.cover || '';
        downloadInput.value = game.download || '';

        gameModal.classList.remove('hidden');
    } catch (error) {
       // Error already handled by makeRequest
       // showError('Failed to load game details: ' + error.message);
    }
}

// Save game (add or update)
async function saveGame(e) {
    e.preventDefault();

    const originalText = saveGameBtn.textContent;
    saveGameBtn.disabled = true;
    saveGameBtn.innerHTML = '<div class="loading"></div> Saving...';

    try {
        // Basic validation
        if (!titleInput.value.trim() || !platformInput.value.trim() || !genreInput.value.trim() || !coverInput.value.trim() || !downloadInput.value.trim()) {
            throw new Error("Please fill in all required fields.");
        }

        const gameData = {
            title: titleInput.value.trim(),
            platform: platformInput.value.trim(),
            // Ensure genre is always an array
            genre: genreInput.value.split(',').map(g => g.trim()).filter(g => g), // Filter empty strings
            description: descriptionInput.value.trim(),
            cover: coverInput.value.trim(),
            download: downloadInput.value.trim()
        };

        const gameId = gameIdInput.value;
        let response;

        if (gameId) {
            // Update existing game
            response = await makeRequest(`/games/${gameId}`, 'PUT', gameData);
            showSuccess('Game updated successfully');
        } else {
            // Add new game
            response = await makeRequest('/games', 'POST', gameData);
            showSuccess('Game added successfully');
        }

         if (response !== null) { // Only proceed if request was successful
             loadGames(); // Refresh the list
             closeModal(); // Close modal on success
         }

    } catch (error) {
        showError('Failed to save game: ' + error.message);
    } finally {
        // Restore button state
        saveGameBtn.disabled = false;
        saveGameBtn.textContent = originalText;
    }
}


// Delete game
async function deleteGame(id) {
    if (!confirm('Are you sure you want to delete this game?')) return;

    try {
        await makeRequest(`/games/${id}`, 'DELETE');
        showSuccess('Game deleted successfully');

        // If we deleted the last item on the current page (and it's not the first page), go back a page
        if (gamesList.children.length === 1 && currentPage > 1) {
             // Check if total games require going back
             const potentialTotalGames = totalGames - 1;
             if ( (currentPage - 1) * gamesPerPage >= potentialTotalGames && currentPage > 1) {
                currentPage--;
             }
        } else if (gamesList.children.length === 1 && currentPage === 1) {
            // If it was the only game on the first page, reset pagination info potentially
             totalGames = 0;
             totalPages = 0;
        }


        loadGames(); // Refresh list and pagination
    } catch (error) {
       // Error handled by makeRequest
       // showError('Failed to delete game: ' + error.message);
    }
}

// Close game modal
function closeModal() {
    gameModal.classList.add('hidden');
    gameForm.reset(); // Reset form when closing
}


// --- Blog Tab Functions ---

function switchTab(tabName) {
    // Hide all tab content
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Show selected tab content
    const selectedTabContent = document.getElementById(`${tabName}-tab`);
    if (selectedTabContent) {
        selectedTabContent.classList.add('active');
    } else {
         console.error(`Tab content not found for: ${tabName}-tab`);
         return; // Exit if tab content doesn't exist
    }


    // Update tab buttons appearance
    tabBtns.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    // Load data for the newly activated tab
    if (tabName === 'games') {
        currentPage = 1; // Reset page when switching to games
        loadGames();
    } else if (tabName === 'blog') {
        currentBlogPage = 1; // Reset page when switching to blog
        loadBlogPosts();
    }
}


async function loadBlogPosts() {
    if (!authToken) return; // Don't load if not logged in
    try {
        let url = `/blog-posts?page=${currentBlogPage}&limit=${postsPerPage}`;
         const query = blogSearchInput.value.trim();
         if (query) {
            url += `&q=${encodeURIComponent(query)}`;
         }

        const response = await makeRequest(url);
         if (!response) return; // Handle cases where makeRequest returns null

        totalPosts = response.totalPosts;
        totalBlogPages = response.totalPages;

        displayBlogPosts(response.posts);
        updateBlogPaginationUI();
    } catch (error) {
        // Error is already shown by makeRequest or subsequent calls
        // showError('Failed to load blog posts: ' + error.message);
    }
}

function updateBlogPaginationUI() {
    blogPageInfo.textContent = `Page ${currentBlogPage} of ${totalBlogPages} (${totalPosts} posts)`;
    blogPrevPageBtn.disabled = currentBlogPage === 1;
    blogNextPageBtn.disabled = currentBlogPage === totalBlogPages || totalBlogPages === 0;
}

function blogPrevPage() {
    if (currentBlogPage > 1) {
        currentBlogPage--;
        loadBlogPosts();
    }
}

function blogNextPage() {
    if (currentBlogPage < totalBlogPages) {
        currentBlogPage++;
        loadBlogPosts();
    }
}

function displayBlogPosts(posts) {
    postsList.innerHTML = '';

    if (!posts || posts.length === 0) {
        postsList.innerHTML = '<p class="no-posts">No posts found.</p>';
        return;
    }

    posts.forEach(post => {
        const postCard = document.createElement('div');
        postCard.className = 'post-card';

        // Format date safely
        let formattedDate = 'Date unknown';
        try {
            if (post.createdAt) {
                const postDate = new Date(post.createdAt);
                 // Check if date is valid before formatting
                 if (!isNaN(postDate.getTime())) {
                    formattedDate = postDate.toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                 }
            }
        } catch (e) {
             console.error("Error formatting date:", e);
        }


        // Create YouTube embed if video URL exists
        let videoEmbed = '';
        if (post.video) {
            const videoId = extractYouTubeId(post.video);
            if (videoId) {
                // Ensure using HTTPS for YouTube embeds
                videoEmbed = `
                    <div class="post-video-container">
                        <iframe src="https://www.youtube.com/embed/${videoId}"
                                title="YouTube video player"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                    </div>
                `;
            }
        }

        // Create image if exists
        let imageContent = '';
        if (post.image) {
            imageContent = `<img src="${post.image}" alt="${post.title || 'Blog post image'}" class="post-image" onerror="this.style.display='none'; console.error('Failed to load image: ${post.image}')">`;
        }

         // Basic sanitization for content display (replace with a proper library if needed for security)
         const safeContent = post.content ? post.content.replace(/</g, "&lt;").replace(/>/g, "&gt;") : 'No content.';


        postCard.innerHTML = `
            <div class="post-header">
                <h3 class="post-title">${post.title || 'Untitled Post'}</h3>
                <div class="post-meta">
                    <span>By ${post.author || 'Unknown Author'}</span>
                    <span>•</span>
                    <span>${formattedDate}</span>
                </div>
            </div>
            <div class="post-content">
                ${imageContent}
                ${videoEmbed}
                <p>${safeContent}</p>
            </div>
            <div class="post-actions">
                <button class="edit-post-btn" data-id="${post.id}">Edit</button>
                <button class="delete-post-btn" data-id="${post.id}">Delete</button>
            </div>
        `;

        postsList.appendChild(postCard);
    });

    // Re-attach event listeners to new buttons
     document.querySelectorAll('#blog-tab .edit-post-btn').forEach(btn => {
        btn.removeEventListener('click', handleEditPostClick); // Remove old listener if any
        btn.addEventListener('click', handleEditPostClick);
    });

    document.querySelectorAll('#blog-tab .delete-post-btn').forEach(btn => {
        btn.removeEventListener('click', handleDeletePostClick); // Remove old listener if any
        btn.addEventListener('click', handleDeletePostClick);
    });
}

// Event handlers for post buttons
function handleEditPostClick(event) {
    editBlogPost(event.target.dataset.id);
}

function handleDeletePostClick(event) {
    deleteBlogPost(event.target.dataset.id);
}


function extractYouTubeId(url) {
    if (!url) return null;
     // More robust regex to handle various YouTube URL formats including shorts and youtu.be
    const regExp = /^.*(?:(?:youtu\.be\/|v\/|vi\/|u\/\w\/|embed\/|shorts\/|watch\?v=)|(?:youtu\.be\/|v\/|vi\/|u\/\w\/|embed\/|shorts\/|watch\?.*[&?]v=))([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[1] && match[1].length === 11) ? match[1] : null;
}


async function searchBlogPosts() {
    currentBlogPage = 1; // Reset page when searching
    loadBlogPosts();
}

function addNewBlogPost() {
    postModalTitle.textContent = 'Add New Post';
    postForm.reset();
    postIdInput.value = ''; // Clear ID
    postModal.classList.remove('hidden');
}

async function editBlogPost(id) {
    try {
        const post = await makeRequest(`/blog-posts/${id}`);
        if (!post) {
            showError('Post not found or failed to load.');
            return;
        }

        postModalTitle.textContent = 'Edit Post';
        postIdInput.value = post.id;
        postTitleInput.value = post.title || '';
        postAuthorInput.value = post.author || '';
        postContentInput.value = post.content || '';
        postImageInput.value = post.image || '';
        postVideoInput.value = post.video || '';

        postModal.classList.remove('hidden');
    } catch (error) {
       // Error handled by makeRequest
       // showError('Failed to load post details: ' + error.message);
    }
}

async function saveBlogPost(e) {
    e.preventDefault();

    const originalText = savePostBtn.textContent;
    savePostBtn.disabled = true;
    savePostBtn.innerHTML = '<div class="loading"></div> Saving...';

    try {
         // Basic validation
        if (!postTitleInput.value.trim() || !postAuthorInput.value.trim() || !postContentInput.value.trim()) {
            throw new Error("Please fill in Title, Author, and Content.");
        }

        const postData = {
            title: postTitleInput.value.trim(),
            author: postAuthorInput.value.trim(),
            content: postContentInput.value.trim(),
             // Send null if fields are empty, otherwise send trimmed value
            image: postImageInput.value.trim() || null,
            video: postVideoInput.value.trim() || null
        };

        const postId = postIdInput.value;
        let response;

        if (postId) {
            response = await makeRequest(`/blog-posts/${postId}`, 'PUT', postData);
            showSuccess('Post updated successfully');
        } else {
            response = await makeRequest('/blog-posts', 'POST', postData);
            showSuccess('Post added successfully');
        }

         if (response !== null) { // Only proceed if request was successful
            loadBlogPosts();
            closePostModal();
        }
    } catch (error) {
        showError('Failed to save post: ' + error.message);
    } finally {
        savePostBtn.disabled = false;
        savePostBtn.textContent = originalText;
    }
}

async function deleteBlogPost(id) {
    if (!confirm('Are you sure you want to delete this post?')) return;

    try {
        await makeRequest(`/blog-posts/${id}`, 'DELETE');
        showSuccess('Post deleted successfully');

         // Adjust pagination if deleting the last item on a page
         if (postsList.children.length === 1 && currentBlogPage > 1) {
             const potentialTotalPosts = totalPosts - 1;
             if ( (currentBlogPage - 1) * postsPerPage >= potentialTotalPosts && currentBlogPage > 1) {
                currentBlogPage--;
             }
         } else if (postsList.children.length === 1 && currentBlogPage === 1) {
            totalPosts = 0;
            totalBlogPages = 0;
         }


        loadBlogPosts(); // Refresh list
    } catch (error) {
       // Error handled by makeRequest
       // showError('Failed to delete post: ' + error.message);
    }
}

function closePostModal() {
    postModal.classList.add('hidden');
    postForm.reset(); // Reset form on close
}


// --- Authentication Functions ---

async function login() {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    if (!username || !password) {
        showError('Please enter both username and password');
        return;
    }

    // Disable button during login attempt
    loginBtn.disabled = true;
    loginBtn.textContent = 'Logging in...';


    try {
         // Use POST for login as it sends credentials in the body
        const data = await makeRequest('/login', 'POST', { username, password });

         if (data && data.token) { // Check if token exists in response
             localStorage.setItem('adminToken', data.token);
             authToken = data.token;
             loginError.textContent = ''; // Clear previous errors
             loginContainer.classList.add('hidden');
             adminPanel.classList.remove('hidden');
             // Load initial data for the default tab (games)
             switchTab('games');
         } else {
             // Handle cases where login might succeed but returns no token, or returns specific error
             throw new Error(data?.message || 'Login failed: Invalid credentials or server error.');
         }
    } catch (error) {
        // Use the error message from makeRequest or the caught error
        showError(error.message || 'Login failed');
        // Clear password field on failed login attempt for security
        passwordInput.value = '';
    } finally {
         // Re-enable login button regardless of success or failure
        loginBtn.disabled = false;
        loginBtn.textContent = 'Login';
    }
}

function logout() {
    localStorage.removeItem('adminToken');
    authToken = null;
    // Hide admin panel, show login
    adminPanel.classList.add('hidden');
    loginContainer.classList.remove('hidden');
    // Clear login form fields
    usernameInput.value = '';
    passwordInput.value = '';
     // Optionally clear lists and reset pagination states
     gamesList.innerHTML = '';
     postsList.innerHTML = '';
     currentPage = 1;
     currentBlogPage = 1;
     totalGames = 0;
     totalPages = 1;
     totalPosts = 0;
     totalBlogPages = 1;
     updatePaginationUI();
     updateBlogPaginationUI();
     // Clear any lingering error/success messages
     clearMessages();
}


// --- Utility Functions ---

// Show error message
function showError(message) {
    showMessage(message, 'error-message');
}

// Show success message
function showSuccess(message) {
    showMessage(message, 'success-message');
}

// Generic message display function
function showMessage(message, className) {
     clearMessages(); // Clear existing messages first

    const messageElement = document.createElement('div');
    messageElement.className = className; // Use class for styling
    messageElement.textContent = message;

    // Try to insert after the header, otherwise prepend to admin panel
    const header = adminPanel.querySelector('header');
    if (header && header.parentNode === adminPanel) { // Check if header is direct child
        adminPanel.insertBefore(messageElement, header.nextSibling);
    } else {
        adminPanel.prepend(messageElement); // Fallback if header isn't found correctly
    }


    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (messageElement.parentNode) { // Check if still attached
             messageElement.remove();
        }
    }, 5000);
}

// Clear all error/success messages
function clearMessages() {
    document.querySelectorAll('.error-message, .success-message').forEach(el => el.remove());
    // Also clear login specific error
    if (loginError) {
        loginError.textContent = '';
    }
}


// --- Event Listeners Setup (MERGED) ---
function setupEventListeners() {
    // Clear existing listeners to prevent duplicates if init is called multiple times
    // (Note: This requires storing references or using anonymous functions carefully)
    // For simplicity here, we assume init is called once. If not, a more robust
    // listener management strategy would be needed.

    // === Login/Logout Listeners ===
    if (loginBtn) loginBtn.addEventListener('click', login);
    if (passwordInput) passwordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') login();
    });
    if (logoutBtn) logoutBtn.addEventListener('click', logout);

    // === Tab Switching Listeners ===
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // === Games Tab Listeners ===
    if (searchBtn) searchBtn.addEventListener('click', searchGames);
    if (searchInput) searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchGames();
    });
    if (addGameBtn) addGameBtn.addEventListener('click', addNewGame);
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
    if (gameForm) gameForm.addEventListener('submit', saveGame);
    if (prevPageBtn) prevPageBtn.addEventListener('click', prevPage);
    if (nextPageBtn) nextPageBtn.addEventListener('click', nextPage);
    if (platformFilter) platformFilter.addEventListener('change', () => {
        currentPage = 1; // Reset to first page when changing filter
        loadGames();
    });
     // Close game modal on outside click
     window.addEventListener('click', (e) => {
        if (e.target === gameModal) {
            closeModal();
        }
     });


    // === Blog Tab Listeners ===
    if (addPostBtn) addPostBtn.addEventListener('click', addNewBlogPost);
    if (closePostBtn) closePostBtn.addEventListener('click', closePostModal);
    if (postForm) postForm.addEventListener('submit', saveBlogPost);
    if (blogSearchBtn) blogSearchBtn.addEventListener('click', searchBlogPosts);
    if (blogSearchInput) blogSearchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchBlogPosts();
    });
    if (blogPrevPageBtn) blogPrevPageBtn.addEventListener('click', blogPrevPage);
    if (blogNextPageBtn) blogNextPageBtn.addEventListener('click', blogNextPage);
     // Close post modal on outside click
     window.addEventListener('click', (e) => {
         if (e.target === postModal) {
             closePostModal();
         }
     });

     // Note: Listeners for edit/delete buttons inside game/post cards are added dynamically in displayGames/displayBlogPosts functions after cards are created.
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', init);